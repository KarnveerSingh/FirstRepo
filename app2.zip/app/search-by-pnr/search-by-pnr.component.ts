import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-by-pnr',
  templateUrl: './search-by-pnr.component.html',
  styleUrls: ['./search-by-pnr.component.css']
})
export class SearchByPnrComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
