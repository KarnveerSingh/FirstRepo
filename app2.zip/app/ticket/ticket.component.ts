import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-ticket',
  templateUrl: './ticket.component.html',
  styleUrls: ['./ticket.component.css']
})
export class TicketComponent implements OnInit {

  TicketForm!:FormGroup;
  constructor() { }

  ngOnInit(): void {

    this.TicketForm = new FormGroup({
      PassengerName :new FormControl('',[Validators.required]),
      PassengerEmail :new FormControl('',[Validators.required]),
      Gender :new FormControl('',[Validators.required]),
      Age :new FormControl('',[Validators.required]),
      OptForMeal :new FormControl('',[Validators.required]),
      SeatNumber :new FormControl('',[Validators.required]),
     
    })
  }


  TicketBook(val:any){
    console.log(val);
  }
}
